import React from "react";

const SuperAdminSidebar = () => {
    return (
        <>
            <div className="set-max-width-252">
                <ul>
                    <li>User Management</li>
                    <li>Role Assigning</li>
                    <li>Rejected NADs</li>
                    <li>All QA Passed</li>
                </ul>
            </div>
        </>
    );
};

export default SuperAdminSidebar;
