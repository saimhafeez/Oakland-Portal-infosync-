import React from "react";

const Sidebar = () => {
  return (
    <>
      <div className="set-max-width-252">
        <ul>
          <li>Sidebar 1</li>
          <li>Sidebar 2</li>
          <li>Sidebar 3</li>
          <li>Sidebar 4</li>
          <li>Sidebar 5</li>
          <li>Sidebar 6</li>
        </ul>
      </div>
    </>
  );
};

export default Sidebar;
