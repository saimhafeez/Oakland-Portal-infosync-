export const authData = {
  isAuthenticated: true,
  isActivated: true,
};
